-- MAAK Enterprises initial schema. Run in Supabase SQL Editor.
create extension if not exists pgcrypto;

create table if not exists public.admin_users (
  user_id uuid primary key references auth.users(id) on delete cascade,
  created_at timestamptz not null default now()
);

create or replace function public.is_maak_admin()
returns boolean language sql stable security definer set search_path = public
as $$ select exists (select 1 from public.admin_users where user_id = auth.uid()); $$;

create table if not exists public.properties (
  id uuid primary key default gen_random_uuid(),
  title text not null,
  slug text not null unique,
  property_type text not null,
  purpose text not null check (purpose in ('Sale','Rent')),
  price numeric(16,2),
  currency text not null default 'PKR',
  location text not null,
  size text not null,
  bedrooms integer,
  bathrooms integer,
  description text,
  image_urls text[] not null default '{}',
  featured boolean not null default false,
  status text not null default 'draft' check (status in ('draft','available','sold','archived')),
  published_at timestamptz,
  created_by uuid references auth.users(id),
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create table if not exists public.construction_projects (
  id uuid primary key default gen_random_uuid(),
  title text not null,
  slug text not null unique,
  division text not null default 'construction',
  location text not null,
  status text not null default 'Ongoing' check (status in ('Ongoing','Completed')),
  description text,
  image_urls text[] not null default '{}',
  is_published boolean not null default false,
  created_by uuid references auth.users(id),
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create table if not exists public.inquiries (
  id uuid primary key default gen_random_uuid(),
  name text not null,
  email text,
  phone text not null,
  division text not null,
  property_id uuid references public.properties(id) on delete set null,
  message text not null,
  consent boolean not null default false,
  source text not null default 'website',
  status text not null default 'new' check (status in ('new','contacted','viewing','negotiation','won','lost')),
  notes text,
  follow_up_at date,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

alter table public.admin_users enable row level security;
alter table public.properties enable row level security;
alter table public.construction_projects enable row level security;
alter table public.inquiries enable row level security;

create policy "Users can read their own admin membership" on public.admin_users for select to authenticated using (user_id = auth.uid());
create policy "Public can view available published properties" on public.properties for select to anon, authenticated using (status='available' and published_at is not null);
create policy "Admins can view all properties" on public.properties for select to authenticated using (public.is_maak_admin());
create policy "Admins can insert properties" on public.properties for insert to authenticated with check (public.is_maak_admin());
create policy "Admins can update properties" on public.properties for update to authenticated using (public.is_maak_admin()) with check (public.is_maak_admin());
create policy "Admins can delete properties" on public.properties for delete to authenticated using (public.is_maak_admin());

create policy "Public can view published projects" on public.construction_projects for select to anon, authenticated using (is_published=true);
create policy "Admins can view all projects" on public.construction_projects for select to authenticated using (public.is_maak_admin());
create policy "Admins can insert projects" on public.construction_projects for insert to authenticated with check (public.is_maak_admin());
create policy "Admins can update projects" on public.construction_projects for update to authenticated using (public.is_maak_admin()) with check (public.is_maak_admin());
create policy "Admins can delete projects" on public.construction_projects for delete to authenticated using (public.is_maak_admin());

create policy "Public can submit consented enquiries" on public.inquiries for insert to anon, authenticated with check (consent=true and status='new');
create policy "Admins can read enquiries" on public.inquiries for select to authenticated using (public.is_maak_admin());
create policy "Admins can update enquiries" on public.inquiries for update to authenticated using (public.is_maak_admin()) with check (public.is_maak_admin());
create policy "Admins can delete enquiries" on public.inquiries for delete to authenticated using (public.is_maak_admin());

-- Keep public insert permissions narrow: no client can set status, notes, follow-up or timestamps.
revoke all on public.inquiries from anon, authenticated;
grant insert (name,email,phone,division,property_id,message,consent,source) on public.inquiries to anon, authenticated;
grant select, update, delete on public.inquiries to authenticated;
grant select on public.properties, public.construction_projects to anon, authenticated;
grant insert, update, delete on public.properties, public.construction_projects to authenticated;
grant select on public.admin_users to authenticated;

-- Create the public-read media bucket. Only admins may upload or delete files.
insert into storage.buckets (id,name,public) values ('maak-media','maak-media',true) on conflict (id) do nothing;
create policy "Public can read MAAK media" on storage.objects for select to anon, authenticated using (bucket_id='maak-media');
create policy "Admins can upload MAAK media" on storage.objects for insert to authenticated with check (bucket_id='maak-media' and public.is_maak_admin());
create policy "Admins can update MAAK media" on storage.objects for update to authenticated using (bucket_id='maak-media' and public.is_maak_admin()) with check (bucket_id='maak-media' and public.is_maak_admin());
create policy "Admins can delete MAAK media" on storage.objects for delete to authenticated using (bucket_id='maak-media' and public.is_maak_admin());
