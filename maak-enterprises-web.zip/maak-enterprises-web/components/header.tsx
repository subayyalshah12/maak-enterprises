import Link from 'next/link';
import Image from 'next/image';
import { Menu } from 'lucide-react';
const links = [['About','/about'],['Real Estate','/real-estate'],['Construction','/construction'],['Education','/education'],['Projects','/projects'],['Contact','/contact']] as const;
export function Header() { return <header className="site-header"><Link href="/" className="brand" aria-label="MAAK Enterprises home"><Image src="/maak-logo.png" alt="MAAK Enterprises Company" width={78} height={72} priority /></Link><nav className="desktop-nav">{links.map(([label,href])=><Link href={href} key={href}>{label}</Link>)}</nav><Link href="/contact" className="button button-small header-cta">Get in touch</Link><details className="mobile-nav"><summary aria-label="Open navigation"><Menu size={23}/></summary><nav>{links.map(([label,href])=><Link href={href} key={href}>{label}</Link>)}</nav></details></header> }
