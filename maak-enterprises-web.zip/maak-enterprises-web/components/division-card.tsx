import Link from 'next/link'; import { ArrowUpRight } from 'lucide-react';
export function DivisionCard({number,title,copy,href}:{number:string;title:string;copy:string;href:string}){return <Link href={href} className="division-card"><span className="card-number">{number}</span><div><h3>{title}</h3><p>{copy}</p></div><ArrowUpRight size={20}/></Link>}
